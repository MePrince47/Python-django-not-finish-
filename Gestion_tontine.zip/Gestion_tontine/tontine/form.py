from django import forms
from .models import Tontine

""" class RowTontineForm(forms.Form):
    nom = forms.CharField(max_length=25, widget=forms.TextInput(attrs={'placeholder': 'Entrer le nom', 'style': 'width: 600px;', 'class': 'form-control'}))
    date_creation = forms.DateField(widget=forms.TextInput(attrs={'placeholder': 'Entrer la date de création', 'style': 'width: 600px;', 'class': 'form-control'}))
    slogan = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={'placeholder': 'Entrer le slogan', 'style': 'width: 600px;', 'class': 'form-control'}))
    regle = forms.CharField(max_length=250, required=False, widget=forms.Textarea(attrs={'placeholder': 'Entrer le(s) regle(s)', 'style': 'width: 600px;', 'class': 'form-control', 'rows':5, 'cols':10})) """
class RowTontineForm(forms.ModelForm):
    nom = forms.CharField(max_length=25, widget=forms.TextInput(attrs={'placeholder': 'Entrer le nom', 'style': 'width: 600px;', 'class': 'form-control'}))
    date_creation = forms.DateField(widget=forms.TextInput(attrs={'placeholder': 'Entrer la date de création', 'style': 'width: 600px;', 'class': 'form-control'}))
    slogan = forms.CharField(max_length=50, required=False, widget=forms.TextInput(attrs={'placeholder': 'Entrer le slogan', 'style': 'width: 600px;', 'class': 'form-control'}))
    regle = forms.CharField(max_length=250, required=False, widget=forms.Textarea(attrs={'placeholder': 'Entrer le(s) regle(s)', 'style': 'width: 600px;', 'class': 'form-control', 'rows':5, 'cols':10}))

    class Meta:
        model = Tontine
        fields = ['nom','date_creation','slogan','regle']