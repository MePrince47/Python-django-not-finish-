from django.shortcuts import render, redirect
from django.contrib import messages
from .models import *
from .form import RowTontineForm
from django.views.generic import ListView
from django.db.models import Q

# Create your views here.
def home(request):
    return render(request, 'tontine/home.html')

def finance(request):
    return render(request, 'tontine/finance.html')

def structure(request):
    return render(request, 'tontine/structure.html')

def rapports(request):
    return render(request, 'tontine/rapports.html')

def tontine(request):
    context = {
        'tontines': Tontine.objects.all()
    }
    return render(request, 'tontine/structure/gestion_de_la_tontine.html', context)

""" def TontineCreate(request):
    return render(request, 'tontine/structure/create.html')
 """


def TontineCreate(request):
    form = RowTontineForm()
    if request.method == 'POST':
        form = RowTontineForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data)
            new = Tontine.objects.create(**form.cleaned_data)
            new.save()
            messages.success(request, f'La tontine a bien ete cree')
            return redirect('/gestion/structure/gestion de la tontine')
        else:
            form = RowTontineForm(request.POST)
    return render(request, 'tontine/structure/create.html', {'form':form})

def TontineModify(request, pk):
    obj = Tontine.objects.get(id_tontine=pk)

    form = RowTontineForm(request.POST or None, instance=obj)

    if form.is_valid():
        form.save()
        messages.success(request, f'La modification a ete effectue')
        return redirect('/gestion/structure/gestion de la tontine')

    return render(request, 'tontine/structure/update.html', {'form':form})

def TontineDelete(request, pk):
    item = Tontine.objects.get(id_tontine=pk)
    item.delete()
    messages.success(request, f'La tontine a bien ete supprime')
    return redirect('/gestion/structure/gestion de la tontine')
    #return render(request, 'tontine/structure/delete.html', {'item':item})

class TontineSearch(ListView):
    model = Tontine
    template_name = 'tontine/structure/search_tontine.html'
    context_object_name = 'tontines'

    def get_queryset(self):
        query = self.request.GET.get('query')
        tontines=Tontine.objects.filter(Q(nom__icontains=query))
        return tontines

def all_tontine(request):
    stud = Tontine.objects.all()
    return render(request,'tontine/statistique/rapports.html',{'stu':stud})  

def all_members(request,id):
    if request.method =='POST':
        pi = Tontine.objects.get(pk = id)
    appart = AppartenirTontine.objects.all()
    cpt = 0
    for temp in appart:
        if temp.id_tontine.id_tontine == id:
                nom = temp.id_membre
                cpt+=1 
    memb = Membre.objects.all()
    ton = Tontine.objects.all()
    return render(request,'tontine/statistique/rapports_membre.html',{'compteur':cpt,'app':appart,'id':id,'meb':memb,'tont':ton})  

def all_stat(request,id):
    all_cotisation = Cotiser.objects.all()
    cpt = 0
    for temp in all_cotisation:
        nom = ''
        if temp.id_membre.id_membre == id:
            nom = temp.id_membre
            cpt+=1

    all_pret =  Pret.objects.all()
    cpt_pret = 0
    for temp in all_pret:
        if temp.id_membre.id_membre == id:
            cpt_pret +=1 

    return render(request,'tontine/statistique/membre_stat.html',{'id':id, 'coti':all_cotisation,'pret':all_pret , 'name':nom, 'compteur':cpt ,'compteur_pret':cpt_pret})