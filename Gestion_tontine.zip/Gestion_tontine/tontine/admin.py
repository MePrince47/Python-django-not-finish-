from django.contrib import admin
from .models import *

# Register your models here.
class AdminTontine(admin.ModelAdmin):
    list_display = ('id_tontine', 'nom', 'date_creation', 'slogan', 'regle')

class AdminMembre(admin.ModelAdmin):
    list_display = ('id_membre', 'nom_membre', 'prenom_membre', 'e_mail', 'adresse', 'no_tel', 'date_naissance', 'profession')

class AdminPoste(admin.ModelAdmin):
    list_display = ('id_poste', 'nom_poste')

class AdminCandidat(admin.ModelAdmin):
    list_display = ('id_candidat', 'id_membre', 'id_election', 'id_poste')

class AdminCotisation(admin.ModelAdmin):
    list_display = ('id_tontine', 'nom_cotisation', 'montant', 'date_debut', 'cycle', 'nbr_participants', 'taux_interet')

class AdminFond(admin.ModelAdmin):
    list_display = ('id_fond', 'id_tontine', 'id_membre', 'type_fond', 'nom_fond', 'montant', 'objectif')

class AdminReunion(admin.ModelAdmin):
    list_display = ('id_reunion', 'id_tontine', 'date_reunion', 'beneficiare', 'lieu', 'heure', 'regle', 'motif')

class AdminPret(admin.ModelAdmin):
    list_display = ('id_pret', 'id_tontine', 'id_membre', 'nom_pret', 'date_pret', 'montant_pret', 'date_remboursement', 'interet', 'sanction', 'raison')

class AdminVote(admin.ModelAdmin):
    list_display = ('id_membre', 'id_election', 'id_poste', 'id_candidat')

class AdminElection(admin.ModelAdmin):
    list_display = ('id_election', 'id_tontine', 'date_election', 'heure_election', 'temps_renouvelable')

class AdminCotiser(admin.ModelAdmin):
    list_display = ('id_membre', 'id_tontine', 'date_cotiser')

class AdminAppartenirTontine(admin.ModelAdmin):
    list_display = ('id_membre', 'id_tontine', 'nombre_parts', 'statut')

class AdminParticipantReunion(admin.ModelAdmin):
    list_display = ('id_reunion', 'id_membre')



admin.site.register(Tontine, AdminTontine)
admin.site.register(Membre, AdminMembre)
admin.site.register(Poste, AdminPoste)
admin.site.register(Candidat, AdminCandidat)
admin.site.register(Cotisation, AdminCotisation)
admin.site.register(Fond, AdminFond)
admin.site.register(Reunion, AdminReunion)
admin.site.register(Pret, AdminPret)
admin.site.register(Vote, AdminVote)
admin.site.register(Election, AdminElection)
admin.site.register(Cotiser, AdminCotiser)
admin.site.register(AppartenirTontine, AdminAppartenirTontine)
admin.site.register(ParticipantReunion, AdminParticipantReunion)
