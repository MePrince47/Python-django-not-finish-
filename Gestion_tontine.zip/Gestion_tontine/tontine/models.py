from django.db import models
from django.urls import reverse

class AppartenirTontine(models.Model):
    id_membre = models.ForeignKey('Membre', models.CASCADE, db_column='id_membre')
    id_tontine = models.ForeignKey('Tontine', models.CASCADE, db_column='id_tontine')
    nombre_parts = models.IntegerField()
    statut = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        db_table = 'Appartenir_tontine'
        unique_together = (('id_membre', 'id_tontine'),)


class Candidat(models.Model):
    id_candidat = models.AutoField(primary_key=True)
    id_membre = models.ForeignKey('Membre', models.CASCADE, db_column='id_membre')
    id_election = models.ForeignKey('Election', models.CASCADE, db_column='id_election')
    id_poste = models.ForeignKey('Poste', models.CASCADE, db_column='id_poste')

    class Meta:
        db_table = 'Candidat'


class ContribuerFond(models.Model):
    id_fond = models.ForeignKey('Fond', models.CASCADE, db_column='id_fond')
    id_membre = models.ForeignKey('Membre', models.CASCADE, db_column='id_membre')
    date_contribution = models.DateField(blank=True, null=True)

    class Meta:
        db_table = 'Contribuer_fond'
        unique_together = (('id_fond', 'id_membre'),)


class Cotisation(models.Model):
    id_tontine = models.ForeignKey('Tontine', models.CASCADE, db_column='id_tontine')
    nom_cotisation = models.CharField(max_length=25)
    montant = models.IntegerField()
    date_debut = models.DateField()
    cycle = models.IntegerField()
    nbr_participants = models.IntegerField(blank=True, null=True)
    taux_interet = models.IntegerField()

    class Meta:
        db_table = 'Cotisation'

    def __str__(self):
        return self.nom_cotisation


class Cotiser(models.Model):
    id_membre = models.ForeignKey('Membre', models.CASCADE, db_column='id_membre')
    id_tontine = models.ForeignKey('Tontine', models.CASCADE, db_column='id_tontine')
    date_cotiser = models.DateField()

    class Meta:
        db_table = 'Cotiser'
        unique_together = (('id_membre', 'id_tontine'),)


class Election(models.Model):
    id_election = models.AutoField(primary_key=True)
    id_tontine = models.ForeignKey('Tontine', models.CASCADE, db_column='id_tontine')
    date_election = models.DateField()
    heure_election = models.TimeField()
    temps_renouvelable = models.IntegerField()

    class Meta:
        db_table = 'Election'


class Fond(models.Model):
    id_fond = models.AutoField(primary_key=True)
    id_tontine = models.ForeignKey('Tontine', models.CASCADE, db_column='id_tontine')
    id_membre = models.ForeignKey('Membre', models.CASCADE, db_column='id_membre')
    type_fond = models.CharField(max_length=30)
    nom_fond = models.CharField(max_length=25)
    montant = models.IntegerField()
    objectif = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        db_table = 'Fond'


class Membre(models.Model):
    id_membre = models.AutoField(primary_key=True)
    nom_membre = models.CharField(max_length=15)
    prenom_membre = models.CharField(max_length=15)
    e_mail = models.CharField(max_length=50, blank=True, null=True)
    adresse = models.CharField(max_length=25)
    no_tel = models.IntegerField()
    date_naissance = models.DateField()
    profession = models.CharField(max_length=25)

    class Meta:
        db_table = 'Membre'
    
    def __str__(self):
        return self.nom_membre+" "+self.prenom_membre


class ParticipantReunion(models.Model):
    id_reunion = models.ForeignKey('Reunion', models.CASCADE, db_column='id_reunion')
    id_membre = models.ForeignKey(Membre, models.CASCADE, db_column='id_membre')

    class Meta:
        db_table = 'Participant_reunion'
        unique_together = (('id_reunion', 'id_membre'),)


class Poste(models.Model):
    id_poste = models.AutoField(primary_key=True)
    nom_poste = models.CharField(max_length=30)

    class Meta:
        db_table = 'Poste'

    def __str__(self):
        return self.nom_poste


class Pret(models.Model):
    id_pret = models.AutoField(primary_key=True)
    id_tontine = models.ForeignKey('Tontine', models.CASCADE, db_column='id_tontine')
    id_membre = models.ForeignKey(Membre, models.CASCADE, db_column='id_membre')
    nom_pret = models.CharField(max_length=25)
    date_pret = models.DateField()
    montant_pret = models.IntegerField()
    date_remboursement = models.DateField()
    interet = models.IntegerField()
    sanction = models.CharField(max_length=100, blank=True, null=True)
    raison = models.CharField(max_length=100)

    class Meta:
        db_table = 'Pret'


class Reunion(models.Model):
    id_reunion = models.AutoField(primary_key=True)
    id_tontine = models.ForeignKey('Tontine', models.CASCADE, db_column='id_tontine')
    date_reunion = models.DateField()
    beneficiare = models.CharField(max_length=15)
    lieu = models.CharField(max_length=25)
    heure = models.TimeField()
    regle = models.CharField(max_length=250, blank=True, null=True)
    motif = models.CharField(max_length=250, blank=True, null=True)

    class Meta:
        db_table = 'Reunion'


class Tontine(models.Model):
    id_tontine = models.AutoField(primary_key=True)
    nom = models.CharField(max_length=25)
    date_creation = models.DateField()
    slogan = models.CharField(max_length=50, blank=True, null=True)
    regle = models.CharField(max_length=250, blank=True, null=True)

    class Meta:
        db_table = 'Tontine'

    def __str__(self):
        return self.nom

    def get_absolute_url(self):
        return reverse("update_tontine", kwargs={"pk": self.pk})


class Vote(models.Model):
    id_membre = models.ForeignKey(Membre, models.CASCADE, db_column='id_membre')
    id_election = models.ForeignKey(Election, models.CASCADE, db_column='id_election')
    id_poste = models.ForeignKey(Poste, models.CASCADE, db_column='id_poste')
    id_candidat = models.ForeignKey(Candidat, models.CASCADE, db_column='id_candidat')

    class Meta:
        db_table = 'Vote'
        unique_together = (('id_membre', 'id_election', 'id_poste'),)
