from django.contrib import admin
from django.contrib import admin
from django.urls import path
from tontine import views

urlpatterns = [
	path('admin/', admin.site.urls),
    path('', views.home, name='home'),
    path('finance/', views.finance, name='finance'),
    path('structure/', views.structure, name='structure'),
    path('rapports/', views.all_tontine, name='rapports'),
    path('rapports/<int:id>/', views.all_members, name='rapports_membre'),
    path('rapports/membre_stat/<int:id>/', views.all_stat, name='membre_stat'),
    path('structure/gestion de la tontine', views.tontine, name='gestion_tontine'),
    path('structure/gestion de la tontine/create', views.TontineCreate, name='create_tontine'),
    path('structure/gestion de la tontine/update/<int:pk>', views.TontineModify, name='update_tontine'),
    path('structure/gestion de la tontine/delete/<int:pk>', views.TontineDelete, name='delete_tontine'),
    path('structure/gestion de la tontine/search', views.TontineSearch.as_view(), name='search_tontine'),
]   